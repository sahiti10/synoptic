"""Synoptic source package."""
